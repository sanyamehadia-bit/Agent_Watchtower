# Certa AI Agent Watchtower — Real-Time Backend

Turns the static Watchtower dashboard into a live one. A small Node/Express API
reads metrics from **MongoDB** and serves them as JSON; the dashboard fetches
that JSON on load and **polls every 15 seconds**, so the moment MongoDB changes,
the charts, KPIs, and tables update — no page reload.

```
MongoDB  ──►  Express API (/api/*)  ──►  dashboard (public/index.html, polls every 15s)
```

## What's inside

```
agent-watchtower-backend/
├── src/
│   ├── db.js          # MongoDB connection (Mongoose)
│   ├── models.js      # Collections mirroring every chart/table on the dashboard
│   ├── seedData.js    # Current dashboard numbers (Notion, Hex, Studio Analytics, uber.certa.in)
│   ├── seed.js        # Loads seedData into MongoDB  (npm run seed)
│   ├── routes.js      # REST endpoints + Overall aggregation (weighted accuracy, totals)
│   └── server.js      # Serves the API and the dashboard
├── public/index.html  # The live dashboard (fetches from the API)
├── test/
│   ├── logic.test.js  # No-DB test: exercises the real aggregation + JSON contract
│   └── e2e.test.js    # Full test against an in-memory MongoDB
└── .env.example
```

## Quick start

```bash
cd agent-watchtower-backend
npm install
cp .env.example .env          # set MONGODB_URI (local mongod or Atlas)
npm run seed                  # one-time: load current numbers into MongoDB
npm start                     # serves dashboard + API on http://localhost:4000
```

Open **http://localhost:4000/**. The badge top-right shows "Live · updated …"
when connected, or "Disconnected — retrying" if the API/DB is unreachable.

Need MongoDB locally? Either point `MONGODB_URI` at a free
[MongoDB Atlas](https://www.mongodb.com/atlas) cluster, or run one in Docker:

```bash
docker run -d -p 27017:27017 --name watchtower-mongo mongo:7
```

## API

| Endpoint          | Returns                                                        |
|-------------------|----------------------------------------------------------------|
| `GET /api/dashboard` | Everything the dashboard needs, in one payload (this is what it polls) |
| `GET /api/overall`   | Computed KPIs (total interactions, weighted accuracy, client count) + comparison table + weekly series |
| `GET /api/design`    | Design agent KPIs, weekly turns/accuracy, client table         |
| `GET /api/risk`      | Risk KPIs, raw assessments, weekly volume, journey events, derived SIG Lite/Core summaries |
| `GET /api/data`      | Questionnaire Prefill KPIs, client rows, workflow growth       |
| `GET /api/validation`| Validation KPIs, weekly steps, execution waterfall, impact table |
| `GET /api/config`    | `{ pollIntervalMs }` — how often the dashboard refreshes        |
| `GET /api/health`    | `{ ok, dbState }` — MongoDB connection status                   |

**Computed, not stored:** the Overall tab's total interactions (85,650),
weighted accuracy (94.8%), and active-agent count are calculated from the agent
records at request time. The SIG Lite / SIG Core summaries on the Risk tab are
derived from the raw `riskassessments` collection (averages, counts), so adding
an assessment row automatically updates them.

## How to push real-time data in

Anything that writes to these collections shows up on the dashboard within one
poll cycle. Point your ingestion jobs (from Notion, Hex, Studio Analytics,
uber.certa.in, or the QnA sheet) at the same MongoDB and upsert. Examples:

```js
// A new risk assessment completes → dashboard updates the scatter + SIG summaries
await RiskAssessment.create({ date: 'Jul 1', type: 'SIG Lite', timeMin: 4.1, cost: 8.2, docs: 1, success: true, order: 12 });

// A client's coverage changes → the coverage bar + table update
await DataClient.updateOne({ key: 'wex' }, { $set: { coverage: 22.3, acceptance: 92.1 } });

// Update the Design headline accuracy → Overall weighted accuracy recomputes
await DesignKpi.updateOne({}, { $set: { accuracy: 91.4 } });
```

Lower `POLL_INTERVAL_MS` in `.env` for snappier refresh (e.g. `5000`). For true
push (sub-second) you could later add WebSockets or MongoDB change streams; the
polling model is simpler and plenty for a metrics dashboard.

## Tests

```bash
npm test        # no DB required — verifies aggregation math + exact JSON shape (26 checks)
npm run test:e2e   # full run against an in-memory MongoDB (needs to download a mongod binary)
```

`npm test` injects in-memory stub models so the real route/aggregation code runs
and every endpoint is hit over HTTP. It confirms the computed Overall numbers
match the original dashboard (85,650 interactions, 94.8% accuracy, 19 clients,
etc.). `test:e2e` does the same against a real MongoDB when one can be downloaded.

## Note on the numbers

`seedData.js` reproduces the values currently in the dashboard as of Jun 24–25,
2026. One intentional difference: the Risk tab's SIG Lite "Avg Time" is now the
true mean of its recorded assessments (**5m 41s**) rather than the old
hand-entered label (5m 23s) — because it's computed live from the data. SIG Core
(17m 52s) and every other figure match the original exactly.
