const { mongoose } = require('./db');
const { Schema } = mongoose;

/**
 * All collections mirror the entities shown on the Watchtower dashboard.
 * Each doc carries an `order` where display order matters, and timestamps
 * so you can see when a metric last changed (drives the "last updated" badge).
 */
const opts = { timestamps: true };

// ── Agent meta (drives the Overall comparison table + status) ──
const AgentSchema = new Schema({
  key: { type: String, required: true, unique: true }, // design | data | risk | validation
  name: String,
  clients: Number,
  interactions: Number,             // total AI interactions attributed to this agent
  interactionsLabel: String,        // e.g. "15,285 code changes"
  accuracy: Number,                 // headline accuracy/quality % used for weighted avg
  accuracyLabel: String,            // e.g. "90.9% accuracy · 95.5% non-failure"
  status: String,                   // "Production" | "Early Production"
  statusColor: String,              // css var name, e.g. "accent-green"
  order: Number
}, opts);

// ── Design agent ──
const DesignWeeklySchema = new Schema({
  week: String,          // "W20 May"
  turns: Number,
  accuracy: Number,      // %
  order: Number
}, opts);

const DesignClientSchema = new Schema({
  name: String,
  changes: Number,
  successPct: { type: Number, default: null },
  order: Number
}, opts);

const DesignKpiSchema = new Schema({
  totalTurns: Number,
  accuracy: Number,
  nonFailureRate: Number,
  clients: Number,
  turnDurationP95: String,
  turnDurationSub: String,
  restoreRate: Number
}, opts);

// ── Risk agent ──
const RiskAssessmentSchema = new Schema({
  date: String,          // "Apr 6"
  type: String,          // "SIG Lite" | "SIG Core"
  timeMin: Number,
  cost: Number,
  docs: Number,
  success: { type: Boolean, default: true },
  order: Number
}, opts);

const RiskWeeklySchema = new Schema({
  week: String,          // "Apr 6"
  successful: Number,
  failed: Number,
  order: Number
}, opts);

const RiskJourneyEventSchema = new Schema({
  label: String,
  count: Number,
  stage: String,         // Exploration | Navigation | Validation | Deep dive
  order: Number
}, opts);

const RiskKpiSchema = new Schema({
  timeCompression: String,      // "15x"
  completedAssessments: Number,
  latestAvgProcessing: String,  // "5m 34s"
  latestAvgTrend: String,       // "▼ 51% vs prior"
  feedbackPct: Number
}, opts);

// ── Data / Questionnaire Prefill agent ──
const DataClientSchema = new Schema({
  key: String,           // etsy | paypal | ...
  name: String,
  goLive: String,        // ISO date string
  goLiveLabel: String,
  monthsActive: Number,
  wfDA: Number,          // workflows using the agent
  wfTotal: Number,
  usageRate: Number,
  coverage: Number,
  acceptance: Number,
  fieldsTotal: Number,
  fieldsAI: Number,
  fieldsNotAI: Number,
  fromPublic: Number,
  fromUpload: Number,
  notAssisted: Number,
  humanReplacedPct: Number,
  // historical (Apr 23) snapshot for the progress comparison chart
  wfDA_apr: Number,
  usageRate_apr: Number,
  coverage_apr: Number,
  acceptance_apr: Number,
  order: Number
}, opts);

const DataWorkflowGrowthSchema = new Schema({
  period: String,        // "Apr 23–May 14"
  newWorkflows: Number,
  order: Number
}, opts);

const DataKpiSchema = new Schema({
  humanAcceptanceRate: Number,
  productionClients: Number,
  totalTenants: Number,
  workflowsWithPrefill: Number,
  avgFieldCoverage: Number,
  // AI field fill breakdown (doughnut) totals
  fillFromUploads: Number,
  fillFromPublic: Number,
  fillHumanReplaced: Number
}, opts);

// ── Validation agent ──
const ValidationWeeklySchema = new Schema({
  week: String,          // "May 11–17"
  steps: Number,
  order: Number
}, opts);

const ValidationExecutionSchema = new Schema({
  // single doc capturing the execution waterfall
  totalUsage: Number,          // 301
  aiDecision: Number,          // 277
  manuallyReviewed: Number,    // 161
  accepted: Number,            // 159
  overridden: Number,          // 2
  aiAutoApprove: Number,       // 184
  aiAutoReject: Number,        // 76
  aiManualReview: Number,      // 17
  reviewApprove: Number,       // 110
  reviewReject: Number,        // 42
  reviewManual: Number         // 9
}, opts);

const ValidationImpactSchema = new Schema({
  metric: String,
  before: String,
  after: String,
  improvement: String,
  improvementType: String,     // "up" | "neutral"
  order: Number
}, opts);

const ValidationKpiSchema = new Schema({
  accuracyRate: Number,        // 98.76
  cycleTimeSavedDays: Number,  // 1.05
  cycleTimeSub: String,
  autoApproveRate: Number      // 65.4
}, opts);

// ── Global settings (key/value) — e.g. deduped enterprise client count ──
const SettingSchema = new Schema({
  key: { type: String, required: true, unique: true },
  value: Schema.Types.Mixed
}, opts);

// ── Overall tab weekly series (its own week groupings per agent) ──
const OverallSeriesSchema = new Schema({
  agent: String,   // design | data | risk | validation
  week: String,
  value: Number,
  order: Number
}, opts);

module.exports = {
  Agent: mongoose.model('Agent', AgentSchema),
  DesignWeekly: mongoose.model('DesignWeekly', DesignWeeklySchema),
  DesignClient: mongoose.model('DesignClient', DesignClientSchema),
  DesignKpi: mongoose.model('DesignKpi', DesignKpiSchema),
  RiskAssessment: mongoose.model('RiskAssessment', RiskAssessmentSchema),
  RiskWeekly: mongoose.model('RiskWeekly', RiskWeeklySchema),
  RiskJourneyEvent: mongoose.model('RiskJourneyEvent', RiskJourneyEventSchema),
  RiskKpi: mongoose.model('RiskKpi', RiskKpiSchema),
  DataClient: mongoose.model('DataClient', DataClientSchema),
  DataWorkflowGrowth: mongoose.model('DataWorkflowGrowth', DataWorkflowGrowthSchema),
  DataKpi: mongoose.model('DataKpi', DataKpiSchema),
  ValidationWeekly: mongoose.model('ValidationWeekly', ValidationWeeklySchema),
  ValidationExecution: mongoose.model('ValidationExecution', ValidationExecutionSchema),
  ValidationImpact: mongoose.model('ValidationImpact', ValidationImpactSchema),
  ValidationKpi: mongoose.model('ValidationKpi', ValidationKpiSchema),
  OverallSeries: mongoose.model('OverallSeries', OverallSeriesSchema),
  Setting: mongoose.model('Setting', SettingSchema)
};
