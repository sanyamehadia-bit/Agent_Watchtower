/**
 * Seed data — the exact numbers currently hardcoded in the dashboard HTML,
 * sourced from Notion, Hex, Studio Analytics, uber.certa.in and the Production
 * QnA sheet (as of Jun 24-25, 2026). This makes the backend work out of the box;
 * replace these with live MongoDB writes from your ingestion pipeline over time.
 */

module.exports = {
  agents: [
    { key: 'design', name: 'Design', clients: 15, interactions: 15285, interactionsLabel: '15,285 code changes', accuracy: 90.9, accuracyLabel: '90.9% accuracy · 95.5% non-failure', status: 'Production', statusColor: 'accent-green', order: 1 },
    { key: 'data', name: 'Data', clients: 6, interactions: 58949, interactionsLabel: '58,949 AI fields', accuracy: 94.91, accuracyLabel: '94.91% human acceptance', status: 'Production', statusColor: 'accent-green', order: 2 },
    { key: 'validation', name: 'Validation', clients: 1, interactions: 1385, interactionsLabel: '1,385 data points validated', accuracy: 98.5, accuracyLabel: '98.5% accuracy', status: 'Production', statusColor: 'accent-green', order: 3 },
    { key: 'risk', name: 'Risk', clients: 1, interactions: 10031, interactionsLabel: '10,031 interactions', accuracy: 100, accuracyLabel: '100% success rate', status: 'Early Production', statusColor: 'accent-amber', order: 4 }
  ],

  // ── Design agent ──
  designKpi: {
    totalTurns: 15285, accuracy: 90.9, nonFailureRate: 95.5, clients: 14,
    turnDurationP95: '15m 7s', turnDurationSub: 'Plan: 2m 59s · Build: 13m 43s', restoreRate: 7.7
  },
  designWeekly: [
    { week: 'W20 May', turns: 468, accuracy: 97.52, order: 1 },
    { week: 'W21 May', turns: 175, accuracy: 98.18, order: 2 },
    { week: 'W22 Jun', turns: 292, accuracy: 100, order: 3 },
    { week: 'W23 Jun', turns: 195, accuracy: 87.5, order: 4 },
    { week: 'W24 Jun', turns: 127, accuracy: 95, order: 5 },
    { week: 'W25 Jun', turns: 157, accuracy: 75, order: 6 }
  ],
  designClients: [
    { name: 'MC', changes: 1060, successPct: null, order: 1 },
    { name: 'BP Due Diligence', changes: 573, successPct: 100.0, order: 2 },
    { name: 'KFCU', changes: 558, successPct: 80.0, order: 3 },
    { name: 'Shionogi', changes: 457, successPct: 97.7, order: 4 },
    { name: 'IB Vogt', changes: 401, successPct: 98.0, order: 5 },
    { name: 'Remitly', changes: 320, successPct: null, order: 6 },
    { name: 'Amer Sports', changes: 195, successPct: 95.9, order: 7 },
    { name: 'Dräger', changes: 166, successPct: 91.2, order: 8 },
    { name: 'Littelfuse', changes: 126, successPct: 100.0, order: 9 },
    { name: 'Grab', changes: 51, successPct: null, order: 10 },
    { name: 'Sompo', changes: 49, successPct: null, order: 11 },
    { name: 'PayPal', changes: 101, successPct: null, order: 12 },
    { name: 'Sagent', changes: 43, successPct: 76.0, order: 13 },
    { name: 'Gard', changes: 15, successPct: 100.0, order: 14 }
  ],
  // Overall tab: Design weekly turns (May 19+)
  designOverallWeekly: [
    { week: 'W4 May', turns: 468 }, { week: 'W1 Jun', turns: 175 },
    { week: 'W2 Jun', turns: 292 }, { week: 'W3 Jun', turns: 195 },
    { week: 'W4 Jun', turns: 127 }
  ],

  // ── Risk agent ──
  riskKpi: {
    timeCompression: '15x', completedAssessments: 11, latestAvgProcessing: '5m 34s',
    latestAvgTrend: '▼ 51% vs prior', feedbackPct: 100
  },
  riskAssessments: [
    { date: 'Apr 6', type: 'SIG Core', timeMin: 15.98, cost: 100.43, docs: 1, success: true, order: 1 },
    { date: 'Apr 21', type: 'SIG Core', timeMin: 19.75, cost: 200.45, docs: 3, success: true, order: 2 },
    { date: 'Apr 21', type: 'SIG Lite', timeMin: 11.52, cost: 49.05, docs: 3, success: true, order: 3 },
    { date: 'May 7', type: 'SIG Lite', timeMin: 5.68, cost: 25.96, docs: 1, success: true, order: 4 },
    { date: 'May 18', type: 'SIG Lite', timeMin: 4.47, cost: 8.82, docs: 1, success: true, order: 5 },
    { date: 'Jun 10', type: 'SIG Lite', timeMin: 3.63, cost: 8.55, docs: 1, success: true, order: 6 },
    { date: 'Jun 10', type: 'SIG Lite', timeMin: 3.60, cost: 9.70, docs: 1, success: true, order: 7 },
    { date: 'Jun 15', type: 'SIG Lite', timeMin: 6.90, cost: 22.33, docs: 2, success: true, order: 8 },
    { date: 'Jun 16', type: 'SIG Lite', timeMin: 4.50, cost: 8.73, docs: 1, success: true, order: 9 },
    { date: 'Jun 17', type: 'SIG Lite', timeMin: 6.08, cost: 25.10, docs: 2, success: true, order: 10 },
    { date: 'Jun 17', type: 'SIG Lite', timeMin: 4.78, cost: 8.79, docs: 2, success: true, order: 11 }
  ],
  riskWeekly: [
    { week: 'Apr 6', successful: 1, failed: 0, order: 1 },
    { week: 'Apr 21', successful: 2, failed: 0, order: 2 },
    { week: 'May 5', successful: 1, failed: 0, order: 3 },
    { week: 'May 12', successful: 0, failed: 1, order: 4 },
    { week: 'May 18', successful: 1, failed: 0, order: 5 },
    { week: 'Jun 8', successful: 2, failed: 0, order: 6 },
    { week: 'Jun 15', successful: 4, failed: 0, order: 7 }
  ],
  riskJourneyEvents: [
    { label: 'Expand table row', count: 87, stage: 'Exploration', order: 1 },
    { label: 'Tab switch', count: 75, stage: 'Navigation', order: 2 },
    { label: 'Open citations', count: 74, stage: 'Validation', order: 3 },
    { label: 'Close citations', count: 36, stage: 'Validation', order: 4 },
    { label: 'SOC 2 details tab', count: 15, stage: 'Navigation', order: 5 },
    { label: 'Toggle view', count: 12, stage: 'Navigation', order: 6 },
    { label: 'Filter control status', count: 11, stage: 'Deep dive', order: 7 },
    { label: 'SOC 2 tab (deep)', count: 6, stage: 'Deep dive', order: 8 },
    { label: 'Toggle detailed analysis', count: 5, stage: 'Deep dive', order: 9 },
    { label: 'Filter doc status', count: 4, stage: 'Deep dive', order: 10 }
  ],
  // Overall tab: Risk weekly interactions (attributes)
  riskOverallWeekly: [
    { week: 'W2 Apr', interactions: 2585 }, { week: 'W3 Apr', interactions: 0 },
    { week: 'W4 Apr', interactions: 3084 }, { week: 'W1 May', interactions: 0 },
    { week: 'W2 May', interactions: 499 }, { week: 'W3 May', interactions: 0 },
    { week: 'W4 May', interactions: 499 }, { week: 'W1 Jun', interactions: 0 },
    { week: 'W2 Jun', interactions: 998 }, { week: 'W3 Jun', interactions: 1996 }
  ],

  // ── Data / Questionnaire Prefill agent ──
  dataKpi: {
    humanAcceptanceRate: 94.91, productionClients: 6, totalTenants: 100,
    workflowsWithPrefill: 1781, avgFieldCoverage: 71.89,
    fillFromUploads: 52174, fillFromPublic: 1439, fillHumanReplaced: 5336
  },
  dataClients: [
    { key: 'etsy', name: 'Etsy', goLive: '2024-12-05', goLiveLabel: 'Dec 2024', monthsActive: 18, wfDA: 1053, wfTotal: 1740, usageRate: 60.52, coverage: 94.06, acceptance: 98.78, fieldsTotal: 31340, fieldsAI: 28708, fieldsNotAI: 2632, fromPublic: 0, fromUpload: 28708, notAssisted: 2632, humanReplacedPct: 1.84, wfDA_apr: 973, usageRate_apr: 84.7, coverage_apr: 93.9, acceptance_apr: 99.0, order: 1 },
    { key: 'paypal', name: 'PayPal', goLive: '2025-10-27', goLiveLabel: 'Oct 2025', monthsActive: 8, wfDA: 563, wfTotal: 7721, usageRate: 7.29, coverage: 40.08, acceptance: 91.71, fieldsTotal: 14733, fieldsAI: 12934, fieldsNotAI: 1799, fromPublic: 1367, fromUpload: 11567, notAssisted: 1799, humanReplacedPct: 4.83, wfDA_apr: 368, usageRate_apr: 13.9, coverage_apr: 39.3, acceptance_apr: 88.0, order: 2 },
    { key: 'sagent', name: 'Sagent', goLive: '2025-06-18', goLiveLabel: 'Jun 2025', monthsActive: 12, wfDA: 68, wfTotal: 958, usageRate: 7.10, coverage: 61.42, acceptance: 94.82, fieldsTotal: 11610, fieldsAI: 11035, fieldsNotAI: 575, fromPublic: 0, fromUpload: 11035, notAssisted: 575, humanReplacedPct: 3.87, wfDA_apr: 55, usageRate_apr: 5.8, coverage_apr: 60.5, acceptance_apr: 92.0, order: 3 },
    { key: 'wex', name: 'WEX', goLive: '2026-03-16', goLiveLabel: 'Mar 2026', monthsActive: 3, wfDA: 77, wfTotal: 3002, usageRate: 2.57, coverage: 16.44, acceptance: 90.37, fieldsTotal: 416, fieldsAI: 374, fieldsNotAI: 42, fromPublic: 72, fromUpload: 302, notAssisted: 42, humanReplacedPct: 2.44, wfDA_apr: 31, usageRate_apr: 28.7, coverage_apr: 18.7, acceptance_apr: 78.0, order: 4 },
    { key: 'octanner', name: 'OC Tanner', goLive: '2025-05-22', goLiveLabel: 'May 2025', monthsActive: 13, wfDA: 11, wfTotal: 997, usageRate: 1.10, coverage: 39.90, acceptance: 71.62, fieldsTotal: 780, fieldsAI: 518, fieldsNotAI: 262, fromPublic: 0, fromUpload: 518, notAssisted: 262, humanReplacedPct: 8.59, wfDA_apr: 11, usageRate_apr: 11.4, coverage_apr: 44.9, acceptance_apr: 86.0, order: 5 },
    { key: 'bakerhughes', name: 'Baker Hughes', goLive: '2026-03-15', goLiveLabel: 'Mar 2026', monthsActive: 3, wfDA: 9, wfTotal: 392, usageRate: 2.30, coverage: 59.67, acceptance: 77.84, fieldsTotal: 70, fieldsAI: 44, fieldsNotAI: 26, fromPublic: 0, fromUpload: 44, notAssisted: 26, humanReplacedPct: 7.46, wfDA_apr: 2, usageRate_apr: 66.67, coverage_apr: 79.6, acceptance_apr: 99.0, order: 6 }
  ],
  dataWorkflowGrowth: [
    { period: 'Apr 23–May 14', newWorkflows: 190, order: 1 },
    { period: 'May 15–21', newWorkflows: 9, order: 2 },
    { period: 'May 22–26', newWorkflows: 32, order: 3 },
    { period: 'May 27–Jun 4', newWorkflows: 65, order: 4 },
    { period: 'Jun 5–17', newWorkflows: 62, order: 5 },
    { period: 'Jun 18–24', newWorkflows: 18, order: 6 }
  ],
  // Overall tab: Questionnaire prefill weekly AI fields
  dataOverallWeekly: [
    { week: 'W1 Apr', fields: 1862 }, { week: 'W2 Apr', fields: 1253 },
    { week: 'W3 Apr', fields: 2804 }, { week: 'W4 Apr', fields: 1632 },
    { week: 'W1 May', fields: 2403 }, { week: 'W2 May', fields: 1128 },
    { week: 'W3 May', fields: 2051 }, { week: 'W4 May', fields: 1343 },
    { week: 'W1 Jun', fields: 903 }, { week: 'W2 Jun', fields: 691 }
  ],

  // ── Validation agent ──
  validationKpi: {
    accuracyRate: 98.76, cycleTimeSavedDays: 1.05,
    cycleTimeSub: 'Per banking onboarding · ~5,426 days/year', autoApproveRate: 65.4
  },
  validationWeekly: [
    { week: 'May 11–17', steps: 56, order: 1 },
    { week: 'May 18–24', steps: 56, order: 2 },
    { week: 'May 25–31', steps: 60, order: 3 },
    { week: 'Jun 1–7', steps: 43, order: 4 },
    { week: 'Jun 8–14', steps: 37, order: 5 },
    { week: 'Jun 15–21', steps: 36, order: 6 },
    { week: 'Jun 22–28', steps: 13, order: 7 }
  ],
  validationExecution: {
    totalUsage: 301, aiDecision: 277, manuallyReviewed: 161, accepted: 159, overridden: 2,
    aiAutoApprove: 184, aiAutoReject: 76, aiManualReview: 17,
    reviewApprove: 110, reviewReject: 42, reviewManual: 9
  },
  validationImpact: [
    { metric: 'Cycle Time Saved per Onboarding', before: '—', after: '~1.05 days', improvement: 'per banking onboarding', improvementType: 'up', order: 1 },
    { metric: 'Projected Days Saved / Year', before: '—', after: '~5,426 days', improvement: 'at scale', improvementType: 'up', order: 2 },
    { metric: 'FTE Equivalent Saved', before: '—', after: '~17 FTEs', improvement: 'Annual equivalent', improvementType: 'neutral', order: 3 },
    { metric: 'Auto-Approve Rate', before: '0% (all manual)', after: '65.4%', improvement: '65.4% automated', improvementType: 'up', order: 4 },
    { metric: 'VM Override Rate', before: '—', after: '1.2%', improvement: '98.8% AI decisions upheld', improvementType: 'neutral', order: 5 }
  ],
  // Overall tab: Validation weekly data points
  validationOverallWeekly: [
    { week: 'W4 May', dataPoints: 60 }, { week: 'W1 Jun', dataPoints: 125 },
    { week: 'W2 Jun', dataPoints: 190 }, { week: 'W3 Jun', dataPoints: 150 },
    { week: 'W4 Jun', dataPoints: 175 }
  ]
};
