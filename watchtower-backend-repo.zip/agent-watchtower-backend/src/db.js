const mongoose = require('mongoose');

/**
 * Connect to MongoDB. Reads MONGODB_URI from the environment.
 * Retries a few times so the server survives a slow-starting DB.
 */
async function connect(uri, { retries = 5, delayMs = 2000 } = {}) {
  const target = uri || process.env.MONGODB_URI;
  if (!target) throw new Error('MONGODB_URI is not set');

  mongoose.set('strictQuery', true);

  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      await mongoose.connect(target, { serverSelectionTimeoutMS: 5000 });
      console.log(`[db] connected to MongoDB (${redact(target)})`);
      return mongoose.connection;
    } catch (err) {
      console.warn(`[db] connection attempt ${attempt}/${retries} failed: ${err.message}`);
      if (attempt === retries) throw err;
      await new Promise((r) => setTimeout(r, delayMs));
    }
  }
}

function redact(uri) {
  return uri.replace(/\/\/([^:]+):([^@]+)@/, '//$1:****@');
}

async function disconnect() {
  await mongoose.disconnect();
}

module.exports = { connect, disconnect, mongoose };
