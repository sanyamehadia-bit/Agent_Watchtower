const express = require('express');
const M = require('./models');

const router = express.Router();

// Small helper: strip mongo internals, sort by `order` when present.
const clean = (docs) =>
  docs
    .map((d) => {
      const o = d.toObject ? d.toObject() : d;
      delete o.__v;
      return o;
    })
    .sort((a, b) => (a.order ?? 0) - (b.order ?? 0));

const one = (doc) => {
  if (!doc) return null;
  const o = doc.toObject ? doc.toObject() : doc;
  delete o.__v;
  return o;
};

// ── Per-agent builders ──
async function buildDesign() {
  const [kpi, weekly, clients] = await Promise.all([
    M.DesignKpi.findOne().sort({ updatedAt: -1 }),
    M.DesignWeekly.find(),
    M.DesignClient.find()
  ]);
  return { kpi: one(kpi), weekly: clean(weekly), clients: clean(clients) };
}

async function buildRisk() {
  const [kpi, assessments, weekly, journey] = await Promise.all([
    M.RiskKpi.findOne().sort({ updatedAt: -1 }),
    M.RiskAssessment.find(),
    M.RiskWeekly.find(),
    M.RiskJourneyEvent.find()
  ]);
  const a = clean(assessments);

  // Derive per-type summaries (SIG Lite / SIG Core) from raw assessments.
  const byType = {};
  for (const x of a) {
    const key = x.type === 'SIG Core' ? 'sigcore' : 'siglite';
    (byType[key] ||= { name: x.type, times: [], dates: [], costs: [] });
    byType[key].times.push(x.timeMin);
    byType[key].dates.push(x.date);
    byType[key].costs.push(x.cost);
  }
  const fmt = (min) => {
    const s = Math.round(min * 60);
    return `${Math.floor(s / 60)}m ${s % 60}s`;
  };
  for (const k of Object.keys(byType)) {
    const t = byType[k];
    const avg = t.times.reduce((s, v) => s + v, 0) / t.times.length;
    t.assessments = t.times.length;
    t.triggered = t.times.length;
    t.successRate = 100;
    t.avgTimeMin = +avg.toFixed(2);
    t.avgTime = fmt(avg);
    t.timeCompression = k === 'sigcore' ? '7x' : '15x';
  }

  return { kpi: one(kpi), assessments: a, weekly: clean(weekly), journey: clean(journey), types: byType };
}

async function buildData() {
  const [kpi, clients, growth] = await Promise.all([
    M.DataKpi.findOne().sort({ updatedAt: -1 }),
    M.DataClient.find(),
    M.DataWorkflowGrowth.find()
  ]);
  return { kpi: one(kpi), clients: clean(clients), workflowGrowth: clean(growth) };
}

async function buildValidation() {
  const [kpi, weekly, execution, impact] = await Promise.all([
    M.ValidationKpi.findOne().sort({ updatedAt: -1 }),
    M.ValidationWeekly.find(),
    M.ValidationExecution.findOne().sort({ updatedAt: -1 }),
    M.ValidationImpact.find()
  ]);
  return { kpi: one(kpi), weekly: clean(weekly), execution: one(execution), impact: clean(impact) };
}

async function buildOverall() {
  const [agents, series, setting] = await Promise.all([
    M.Agent.find(),
    M.OverallSeries.find(),
    M.Setting.findOne({ key: 'enterpriseClients' })
  ]);
  const a = clean(agents);

  const totalInteractions = a.reduce((s, x) => s + (x.interactions || 0), 0);
  const weightedAccuracy = totalInteractions
    ? a.reduce((s, x) => s + (x.accuracy || 0) * (x.interactions || 0), 0) / totalInteractions
    : 0;

  // group weekly series by agent, preserving order
  const s = clean(series);
  const weekly = {};
  for (const row of s) {
    (weekly[row.agent] ||= []).push({ week: row.week, value: row.value });
  }

  return {
    kpis: {
      totalInteractions,
      enterpriseClients: setting ? setting.value : a.reduce((sum, x) => sum + (x.clients || 0), 0),
      overallAccuracy: +weightedAccuracy.toFixed(1),
      activeAgents: a.length,
      breakdown: a.map((x) => ({ key: x.key, name: x.name, clients: x.clients, interactions: x.interactions }))
    },
    agents: a,
    weekly
  };
}

// ── Individual endpoints ──
router.get('/design', async (_req, res, next) => { try { res.json(await buildDesign()); } catch (e) { next(e); } });
router.get('/risk', async (_req, res, next) => { try { res.json(await buildRisk()); } catch (e) { next(e); } });
router.get('/data', async (_req, res, next) => { try { res.json(await buildData()); } catch (e) { next(e); } });
router.get('/validation', async (_req, res, next) => { try { res.json(await buildValidation()); } catch (e) { next(e); } });
router.get('/overall', async (_req, res, next) => { try { res.json(await buildOverall()); } catch (e) { next(e); } });

// ── One-shot endpoint the dashboard polls ──
router.get('/dashboard', async (_req, res, next) => {
  try {
    const [overall, design, risk, data, validation] = await Promise.all([
      buildOverall(), buildDesign(), buildRisk(), buildData(), buildValidation()
    ]);
    res.json({ generatedAt: new Date().toISOString(), overall, design, risk, data, validation });
  } catch (e) { next(e); }
});

// ── Frontend runtime config ──
router.get('/config', (_req, res) => {
  res.json({ pollIntervalMs: parseInt(process.env.POLL_INTERVAL_MS || '15000', 10) });
});

router.get('/health', (_req, res) => {
  const state = require('mongoose').connection.readyState; // 1 = connected
  res.json({ ok: state === 1, dbState: state });
});

module.exports = router;
