require('dotenv').config();
const { connect, disconnect } = require('./db');
const M = require('./models');
const D = require('./seedData');

/**
 * Wipes and repopulates every collection from seedData.js.
 * Run with: npm run seed
 * Safe to run repeatedly — it clears each collection first.
 */
async function seed() {
  await connect();

  const overallSeries = [
    ...D.designOverallWeekly.map((r, i) => ({ agent: 'design', week: r.week, value: r.turns, order: i + 1 })),
    ...D.dataOverallWeekly.map((r, i) => ({ agent: 'data', week: r.week, value: r.fields, order: i + 1 })),
    ...D.riskOverallWeekly.map((r, i) => ({ agent: 'risk', week: r.week, value: r.interactions, order: i + 1 })),
    ...D.validationOverallWeekly.map((r, i) => ({ agent: 'validation', week: r.week, value: r.dataPoints, order: i + 1 }))
  ];

  const jobs = [
    [M.Agent, D.agents],
    [M.DesignKpi, [D.designKpi]],
    [M.DesignWeekly, D.designWeekly],
    [M.DesignClient, D.designClients],
    [M.RiskKpi, [D.riskKpi]],
    [M.RiskAssessment, D.riskAssessments],
    [M.RiskWeekly, D.riskWeekly],
    [M.RiskJourneyEvent, D.riskJourneyEvents],
    [M.DataKpi, [D.dataKpi]],
    [M.DataClient, D.dataClients],
    [M.DataWorkflowGrowth, D.dataWorkflowGrowth],
    [M.ValidationKpi, [D.validationKpi]],
    [M.ValidationWeekly, D.validationWeekly],
    [M.ValidationExecution, [D.validationExecution]],
    [M.ValidationImpact, D.validationImpact],
    [M.OverallSeries, overallSeries],
    [M.Setting, [{ key: 'enterpriseClients', value: 19 }]]
  ];

  for (const [Model, docs] of jobs) {
    await Model.deleteMany({});
    await Model.insertMany(docs);
    console.log(`[seed] ${Model.modelName}: ${docs.length} docs`);
  }

  console.log('[seed] done.');
  await disconnect();
}

if (require.main === module) {
  seed().catch((err) => {
    console.error('[seed] failed:', err);
    process.exit(1);
  });
}

module.exports = { seed };
