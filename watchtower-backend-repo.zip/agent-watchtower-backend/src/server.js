require('dotenv').config();
const path = require('path');
const express = require('express');
const cors = require('cors');
const { connect } = require('./db');
const routes = require('./routes');

const app = express();
const PORT = parseInt(process.env.PORT || '4000', 10);

app.use(cors());
app.use(express.json());

// API
app.use('/api', routes);

// Serve the dashboard (public/index.html) at the root
app.use(express.static(path.join(__dirname, '..', 'public')));

// JSON error handler
app.use((err, _req, res, _next) => {
  console.error('[api] error:', err);
  res.status(500).json({ error: err.message });
});

async function start() {
  await connect();
  app.listen(PORT, () => {
    console.log(`[server] Watchtower API + dashboard on http://localhost:${PORT}`);
    console.log(`[server] dashboard:  http://localhost:${PORT}/`);
    console.log(`[server] API sample: http://localhost:${PORT}/api/dashboard`);
  });
}

if (require.main === module) {
  start().catch((err) => {
    console.error('[server] failed to start:', err);
    process.exit(1);
  });
}

module.exports = { app, start };
