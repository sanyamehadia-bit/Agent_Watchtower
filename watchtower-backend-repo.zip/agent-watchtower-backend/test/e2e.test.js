/**
 * End-to-end check: spins up an in-memory MongoDB, seeds it, starts the API,
 * hits every endpoint and asserts the shape + a few key computed numbers.
 * Run with: npm test   (after `npm install`)
 */
const assert = require('assert');
const { MongoMemoryServer } = require('mongodb-memory-server');

(async () => {
  const mongod = await MongoMemoryServer.create(
    process.env.MEMORY_MONGO_VERSION ? { binary: { version: process.env.MEMORY_MONGO_VERSION } } : undefined
  );
  process.env.MONGODB_URI = mongod.getUri('agent_watchtower');
  process.env.PORT = '4599';

  const { connect, disconnect } = require('../src/db');
  const { seed } = require('../src/seed');
  // seed() connects/disconnects itself; run it first
  await seed();

  const { app } = require('../src/server');
  await connect();
  const server = app.listen(4599);
  const base = 'http://127.0.0.1:4599';
  const get = async (p) => { const r = await fetch(base + p); assert.strictEqual(r.status, 200, p + ' status'); return r.json(); };

  let passed = 0;
  const ok = (label) => { console.log('  ✓ ' + label); passed++; };

  // health
  const h = await get('/api/health');
  assert.strictEqual(h.ok, true); ok('health reports connected');

  // dashboard
  const d = await get('/api/dashboard');
  assert.ok(d.generatedAt); ok('dashboard has generatedAt');

  // overall computed values must match the original dashboard
  assert.strictEqual(d.overall.kpis.totalInteractions, 85650); ok('total interactions = 85,650');
  assert.strictEqual(d.overall.kpis.overallAccuracy, 94.8); ok('weighted accuracy = 94.8%');
  assert.strictEqual(d.overall.kpis.enterpriseClients, 19); ok('enterprise clients = 19');
  assert.strictEqual(d.overall.kpis.activeAgents, 4); ok('active agents = 4');
  assert.strictEqual(d.overall.agents.length, 4); ok('4 agents in comparison');
  assert.strictEqual(d.overall.weekly.design.length, 5); ok('overall design weekly series present');

  // design
  assert.strictEqual(d.design.kpi.totalTurns, 15285); ok('design total turns = 15,285');
  assert.strictEqual(d.design.weekly.length, 6); ok('design weekly = 6 weeks');
  assert.strictEqual(d.design.clients.length, 14); ok('design clients = 14');

  // risk — derived types
  assert.strictEqual(d.risk.assessments.length, 11); ok('risk assessments = 11');
  assert.strictEqual(d.risk.types.siglite.assessments, 9); ok('SIG Lite = 9 assessments');
  assert.strictEqual(d.risk.types.sigcore.assessments, 2); ok('SIG Core = 2 assessments');
  assert.strictEqual(d.risk.types.siglite.avgTime, '5m 23s'); ok('SIG Lite avg time = 5m 23s');
  assert.strictEqual(d.risk.journey.length, 10); ok('risk journey events = 10');

  // data
  assert.strictEqual(d.data.clients.length, 6); ok('data clients = 6');
  assert.strictEqual(d.data.kpi.humanAcceptanceRate, 94.91); ok('data acceptance = 94.91%');

  // validation
  assert.strictEqual(d.validation.execution.totalUsage, 301); ok('validation total usage = 301');
  assert.strictEqual(d.validation.impact.length, 5); ok('validation impact rows = 5');
  assert.strictEqual(d.validation.weekly.length, 7); ok('validation weekly = 7 weeks');

  // individual endpoints respond
  for (const p of ['/api/overall', '/api/design', '/api/risk', '/api/data', '/api/validation', '/api/config']) {
    await get(p);
  }
  ok('all individual endpoints return 200');

  console.log(`\nAll ${passed} checks passed.`);

  server.close();
  await disconnect();
  await mongod.stop();
  process.exit(0);
})().catch((err) => { console.error('\nTEST FAILED:', err); process.exit(1); });
