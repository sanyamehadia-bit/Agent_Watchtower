/**
 * Logic + contract test that runs WITHOUT a MongoDB binary.
 * It injects in-memory stub models (backed by seedData) into the require cache
 * so routes.js runs its real aggregation code, then hits every endpoint over HTTP.
 *
 * This validates the parts that carry real risk: the weighted-accuracy math,
 * SIG type derivation, and the exact JSON shape the dashboard consumes.
 *
 * Run: node test/logic.test.js   (no DB required)
 * For a true end-to-end run against Mongo, use `npm test` with a reachable DB.
 */
const assert = require('assert');
const path = require('path');
const Module = require('module');
const D = require('../src/seedData');

// ── Build stub models that mimic the tiny slice of the Mongoose API routes use ──
function doc(o) { return { ...o, toObject() { return { ...o }; } }; }
function collection(rows) {
  const docs = rows.map(doc);
  return {
    find() { return Promise.resolve(docs); },
    // Mongoose queries are thenable AND chainable (.sort()); mimic both.
    findOne() {
      const first = docs[0] || null;
      return { sort() { return Promise.resolve(first); }, then(res, rej) { return Promise.resolve(first).then(res, rej); } };
    }
  };
}

const overallSeries = [
  ...D.designOverallWeekly.map((r, i) => ({ agent: 'design', week: r.week, value: r.turns, order: i + 1 })),
  ...D.dataOverallWeekly.map((r, i) => ({ agent: 'data', week: r.week, value: r.fields, order: i + 1 })),
  ...D.riskOverallWeekly.map((r, i) => ({ agent: 'risk', week: r.week, value: r.interactions, order: i + 1 })),
  ...D.validationOverallWeekly.map((r, i) => ({ agent: 'validation', week: r.week, value: r.dataPoints, order: i + 1 }))
];

const fakeModels = {
  Agent: collection(D.agents),
  DesignKpi: collection([D.designKpi]),
  DesignWeekly: collection(D.designWeekly),
  DesignClient: collection(D.designClients),
  RiskKpi: collection([D.riskKpi]),
  RiskAssessment: collection(D.riskAssessments),
  RiskWeekly: collection(D.riskWeekly),
  RiskJourneyEvent: collection(D.riskJourneyEvents),
  DataKpi: collection([D.dataKpi]),
  DataClient: collection(D.dataClients),
  DataWorkflowGrowth: collection(D.dataWorkflowGrowth),
  ValidationKpi: collection([D.validationKpi]),
  ValidationWeekly: collection(D.validationWeekly),
  ValidationExecution: collection([D.validationExecution]),
  ValidationImpact: collection(D.validationImpact),
  OverallSeries: collection(overallSeries),
  Setting: collection([{ key: 'enterpriseClients', value: 19 }])
};

// Intercept require('./models') from routes.js
const modelsPath = path.join(__dirname, '..', 'src', 'models.js');
const origLoad = Module._load;
Module._load = function (request, parent, isMain) {
  if (parent && parent.filename && parent.filename.endsWith('routes.js') && request === './models') {
    return fakeModels;
  }
  return origLoad.apply(this, arguments);
};

const express = require('express');
const routes = require('../src/routes');
Module._load = origLoad; // restore

(async () => {
  const app = express();
  app.use('/api', routes);
  const server = app.listen(4600);
  const base = 'http://127.0.0.1:4600';
  const get = async (p) => { const r = await fetch(base + p); assert.strictEqual(r.status, 200, p + ' -> ' + r.status); return r.json(); };

  let passed = 0;
  const ok = (l) => { console.log('  ✓ ' + l); passed++; };

  const d = await get('/api/dashboard');
  assert.ok(d.generatedAt); ok('dashboard has generatedAt timestamp');

  // Overall computed values must match the original hardcoded dashboard
  assert.strictEqual(d.overall.kpis.totalInteractions, 85650); ok('total interactions = 85,650');
  assert.strictEqual(d.overall.kpis.overallAccuracy, 94.8); ok('weighted accuracy = 94.8%');
  assert.strictEqual(d.overall.kpis.enterpriseClients, 19); ok('enterprise clients = 19');
  assert.strictEqual(d.overall.kpis.activeAgents, 4); ok('active agents = 4');
  assert.strictEqual(d.overall.weekly.design.length, 5); ok('overall.weekly.design series = 5 points');
  assert.strictEqual(d.overall.weekly.risk.length, 10); ok('overall.weekly.risk series = 10 points');

  // Design
  assert.strictEqual(d.design.kpi.totalTurns, 15285); ok('design total turns = 15,285');
  assert.strictEqual(d.design.weekly.length, 6); ok('design weekly = 6 weeks');
  assert.strictEqual(d.design.clients.length, 14); ok('design clients = 14');
  assert.strictEqual(d.design.weekly[0].week, 'W20 May'); ok('design weekly sorted by order');

  // Risk — derived SIG types
  assert.strictEqual(d.risk.assessments.length, 11); ok('risk assessments = 11');
  assert.strictEqual(d.risk.types.siglite.assessments, 9); ok('SIG Lite derived = 9');
  assert.strictEqual(d.risk.types.sigcore.assessments, 2); ok('SIG Core derived = 2');
  // Avg time is now DERIVED from the raw assessment records (true mean),
  // rather than a hand-curated label. SIG Core matches the old dashboard exactly;
  // SIG Lite is the exact mean of its 9 records (5m 41s).
  assert.strictEqual(d.risk.types.siglite.avgTime, '5m 41s'); ok('SIG Lite avg time = 5m 41s (true mean of 9 records)');
  assert.strictEqual(d.risk.types.sigcore.avgTime, '17m 52s'); ok('SIG Core avg time = 17m 52s (matches dashboard)');
  assert.strictEqual(d.risk.journey.length, 10); ok('risk journey events = 10');

  // Data
  assert.strictEqual(d.data.clients.length, 6); ok('data clients = 6');
  assert.strictEqual(d.data.kpi.humanAcceptanceRate, 94.91); ok('data acceptance = 94.91%');
  assert.strictEqual(d.data.kpi.fillFromUploads, 52174); ok('data fill-from-uploads = 52,174');

  // Validation
  assert.strictEqual(d.validation.execution.totalUsage, 301); ok('validation total usage = 301');
  assert.strictEqual(d.validation.execution.aiAutoApprove, 184); ok('validation auto-approve = 184');
  assert.strictEqual(d.validation.impact.length, 5); ok('validation impact rows = 5');
  assert.strictEqual(d.validation.weekly.length, 7); ok('validation weekly = 7 weeks');

  // Individual endpoints
  for (const p of ['/api/overall', '/api/design', '/api/risk', '/api/data', '/api/validation', '/api/config']) await get(p);
  ok('all individual endpoints return 200');

  const cfg = await get('/api/config');
  assert.ok(typeof cfg.pollIntervalMs === 'number'); ok('/api/config returns pollIntervalMs');

  console.log(`\nAll ${passed} checks passed.`);
  server.close();
  process.exit(0);
})().catch((e) => { console.error('\nTEST FAILED:', e); process.exit(1); });
